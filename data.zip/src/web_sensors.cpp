#include "web_sensors.h"
#include "sensors.h"
#include "web_common.h"
#include "web_theme.h"

extern WindSpeedState gWindSpeed;
extern WindDirState gWindDir;
extern ShtSensorState gSht;
extern RainSensorState gRain;
extern Mpu6050State gMpu;
extern Aht20State gAht20;
extern Bmp280State gBmp280;
extern Ltr390State gLtr;
extern uint32_t gSensRs485Baud;
extern bool gRs485Initialized;
extern String gLastSensTestResult;
extern bool gLastSensTestOk;
extern String gLastSensTestRaw;

#if CURRENT_DEVICE_ROLE == ROLE_SERVER
  extern bool checkPinGuard(AsyncWebServerRequest *request);
#else
  bool checkPinGuard(AsyncWebServerRequest *request) { return true; }
#endif

extern void sensSetEnabled(uint8_t bit, bool on);
extern void sensorsApplyEnabled();
extern void saveSensorConfig();
extern void rs485Init();
extern String compassAbbrev(float deg);

String sensorRowHtml(const String& sensorKey, const String& label, bool enabled, bool hasEverRead, bool isOk, const String& valueText, const String& pinInfo) {
    String color = "gray";
    if(enabled) color = (!hasEverRead) ? "y" : (isOk ? "g" : "r");
    String cssColor = (color=="g") ? "var(--ok)" : (color=="y") ? "var(--warn)" : (color=="r") ? "var(--err)" : "#555";

    String h = "<div class='sens-row' id='sensRow_" + sensorKey + "'>";
    h += "<label class='sens-toggle' style='--sens-color:" + cssColor + "'>"
         "<input type='checkbox' id='sensChk_" + sensorKey + "'"
         + String(enabled ? " checked" : "") +
         " onchange='sensToggle(\"" + sensorKey + "\", this.checked)'>"
         "<span class='slider'></span></label>";
    h += "<span class='sens-name'>" + label;
    if(pinInfo.length()) {
        h += "<span class='pin-info' onclick='this.classList.toggle(\"open\")'>ⓘ"
             "<span class='pin-bubble'>" + pinInfo + "</span></span>";
    }
    h += "</span>";
    h += "<span class='sens-value" + String(valueText.length() ? "" : " dim") + "' id='sensVal_" + sensorKey + "'>";
    h += valueText.length() ? valueText : (enabled ? "meres folyamatban..." : "kikapcsolva");
    h += "</span></div>";
    return h;
}

String sensStatusJsonEntry(const String& key, bool enabled, bool hasEverRead, bool isOk, const String& value) {
    return "\"" + key + "\":{\"enabled\":" + String(enabled?"true":"false") + 
            ",\"hasEverRead\":" + String(hasEverRead?"true":"false") + 
            ",\"ok\":" + String(isOk?"true":"false") + 
            ",\"value\":\"" + value + "\"}";
}

String windSpeedValueText() {
    if(!gWindSpeed.enabled) return "";
    if(!gWindSpeed.lastReadOk && gWindSpeed.lastGoodRead == 0) return "";
    return String(gWindSpeed.speedMs, 1) + " m/s";
}

String windDirValueText() {
    if(!gWindDir.enabled) return "";
    if(!gWindDir.lastReadOk && gWindDir.lastGoodRead == 0) return "";
    return String(gWindDir.directionDeg, 0) + "\xC2\xB0 " + compassAbbrev(gWindDir.directionDeg);
}

String shtValueText() {
    if(!gSht.enabled) return "";
    if(!gSht.lastReadOk && gSht.lastGoodRead == 0) return "";
    return String(gSht.tempC, 1) + " °C, " + String(gSht.humidityPct, 0) + "% RH";
}

String rainValueText() {
    if(!gRain.enabled) return "";
    return String(gRain.percentWet) + "% " + (gRain.isRaining ? "(esik)" : "(szaraz)");
}

String mpuValueText() {
    if(!gMpu.enabled) return "";
    if(!gMpu.lastReadOk && gMpu.lastGoodRead == 0) return "";
    return String(gMpu.accelX,2)+","+String(gMpu.accelY,2)+","+String(gMpu.accelZ,2)+" g";
}

String aht20ValueText() {
    if(!gAht20.enabled) return "";
    if(!gAht20.lastReadOk && gAht20.lastGoodRead == 0) return "";
    return String(gAht20.tempC, 1) + " °C, " + String(gAht20.humidityPct, 0) + "% RH";
}

String bmp280ValueText() {
    if(!gBmp280.enabled) return "";
    if(!gBmp280.lastReadOk && gBmp280.lastGoodRead == 0) return "";
    return String(gBmp280.tempC, 1) + " C, " + String(gBmp280.pressureHpa, 0) + " hPa";
}

String ltrValueText() {
    if(!gLtr.enabled) return "";
    if(!gLtr.lastReadOk && gLtr.lastGoodRead == 0) return "";
    return "UVI " + String(gLtr.uvIndex, 1) + " | " + String(gLtr.lux, 1) + " lx";
}

void handleSensors(AsyncWebServerRequest *request) {
    if (!checkPinGuard(request)) return;
    String html = htmlHead("Szenzorok", "7");

    html += "<script>function copyElement(id){ var e=document.getElementById(id); if(!e)return; var text = e.innerText; navigator.clipboard.writeText(text).then(function() { alert('Vágólapra másolva!'); }).catch(function(err) { alert('Másolás sikertelen.'); }); }</script>";

    html += "<div class='card wide'><h2>Allapot</h2>";
    html += sensorRowHtml("windspeed", "Szelsebesseg", gWindSpeed.enabled, gWindSpeed.lastGoodRead>0, gWindSpeed.lastReadOk, windSpeedValueText());
    html += sensorRowHtml("winddir", "Szelirany", gWindDir.enabled, gWindDir.lastGoodRead>0, gWindDir.lastReadOk, windDirValueText());
    html += sensorRowHtml("sht", "SHT57 ho/para", gSht.enabled, gSht.lastGoodRead>0, gSht.lastReadOk, shtValueText());
    html += sensorRowHtml("rain", "Esoszenzor", gRain.enabled, gRain.lastPoll>0, true, rainValueText());
    html += sensorRowHtml("mpu", "MPU6050 (I2C1)", gMpu.enabled, gMpu.lastGoodRead>0, gMpu.lastReadOk, mpuValueText());
    html += sensorRowHtml("aht20", "AHT20 Hő/Pára (I2C2)", gAht20.enabled, gAht20.lastGoodRead>0, gAht20.lastReadOk, aht20ValueText());
    html += sensorRowHtml("bmp280", "BMP280 Nyomás (I2C2)", gBmp280.enabled, gBmp280.lastGoodRead>0, gBmp280.lastReadOk, bmp280ValueText());
    html += sensorRowHtml("ltr", "LTR-390 UV (I2C2)", gLtr.enabled, gLtr.lastGoodRead>0, gLtr.lastReadOk, ltrValueText());
    html += "</div>";

    html += "<div class='card wide'><h2>RS485 / Modbus beallitasok</h2><form action='/sensconfig' method='POST'><label>RS485 baudrate</label><select name='baud'>";
    const long bauds[] = {1200,2400,4800,9600,19200,38400,57600,115200};
    for(int i=0;i<8;i++){
        html += "<option value='" + String(bauds[i]) + "'" + ((long)gSensRs485Baud == bauds[i] ? " selected" : "") + ">" + String(bauds[i]) + "</option>";
    }
    html += "</select><label>Szelsebesseg Modbus cim</label><input type='number' name='addr_windspeed' min='1' max='247' value='" + String(gWindSpeed.modbusAddr) + "'>";
    html += "<label>Szelirany Modbus cim</label><input type='number' name='addr_winddir' min='1' max='247' value='" + String(gWindDir.modbusAddr) + "'>";
    html += "<label>SHT57 Modbus cim</label><input type='number' name='addr_sht' min='1' max='247' value='" + String(gSht.modbusAddr) + "'>";
    html += "<div class='cb-row'><input type='checkbox' name='rain_modbus' id='rmCb'" + String(gRain.isModbus ? " checked" : "") + "><label for='rmCb'>Esoszenzor RS485/Modbus modban (kulonben analog bemenet)</label></div>";
    html += "<label>Esoszenzor Modbus cim</label><input type='number' name='addr_rain' min='1' max='247' value='" + String(gRain.modbusAddr) + "'><button class='sec'>Mentes</button></form></div>";

    html += "<div class='card wide'><h2>Tesztelés</h2><p class='hint'>Azonnali, egyszeri lekerdezes a kivalasztott eszkozre.</p><div style='display:flex;gap:8px;flex-wrap:wrap;margin-top:8px'>";
    const char* tests[] = {"windspeed", "winddir", "sht", "rain", "mpu", "aht20", "bmp280", "ltr"};
    const char* labels[] = {"Szelsebesseg teszt", "Szelirany teszt", "SHT57 teszt", "Eso teszt", "MPU6050 teszt", "AHT20 teszt", "BMP280 teszt", "LTR-390 teszt"};
    for(int i=0; i<8; i++) {
        html += "<form action='/senstest' method='POST' style='flex:1;min-width:120px'><input type='hidden' name='which' value='" + String(tests[i]) + "'><button class='sec'>" + String(labels[i]) + "</button></form>";
    }
    html += "</div>";
    if(gLastSensTestResult.length()) {
        html += "<div class='msg " + String(gLastSensTestOk ? "ok" : "err") + "' style='margin-top:10px'>" + htmlEscape(gLastSensTestResult) + "</div>";
        if(gLastSensTestRaw.length()) html += "<div class='diag' style='margin-top:6px'>Nyers Modbus valasz: " + htmlEscape(gLastSensTestRaw) + "</div>";
    }
    html += "</div>";

    html += "<div class='card wide'><h2>I2C Scanner <button class='sec' style='padding:4px 8px;font-size:11px;float:right;margin-top:-2px' onclick='copyElement(\"i2cScanBox\")'>Másolás</button></h2>";
    html += "<p class='hint'>Lekérdezi a buszokra (I2C1 és I2C2) csatlakoztatott eszközök hardveres címeit.</p>";
    html += "<button class='sec' style='width:100%; margin-bottom:10px;' onclick='runI2cScan(this)'>🔎 I2C Buszok Szkennelése</button>";
    html += "<div class='diag' id='i2cScanBox' style='min-height:80px; font-family:monospace; white-space:pre-wrap;'>Nyomd meg a gombot a szkenneléshez...</div></div>";

    html += R"js(<script>
function sensToggle(key, on){ fetch('/senstoggle', {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:'key='+encodeURIComponent(key)+'&on='+(on?'1':'0')}); }
function sensPoll(){
    fetch('/sensstatus').then(r=>r.json()).then(d=>{
        for(var key in d){
            var row = document.getElementById('sensRow_'+key); if(!row) continue;
            var val = document.getElementById('sensVal_'+key); var chk = document.getElementById('sensChk_'+key);
            var s = d[key];
            if(val){ val.innerText = s.value || (s.enabled ? 'meres folyamatban...' : 'kikapcsolva'); val.className = 'sens-value' + (s.value ? '' : ' dim'); }
            if(chk) chk.checked = s.enabled;
            var toggle = row.querySelector('.sens-toggle');
            if(toggle){ var color = '#555'; if(s.enabled) color = !s.hasEverRead ? 'var(--warn)' : (s.ok ? 'var(--ok)' : 'var(--err)'); toggle.style.setProperty('--sens-color', color); }
        }
    }).catch(e=>{});
}
function runI2cScan(btn) {
    var orig = btn.innerText; btn.innerText = 'Szkennelés...'; btn.disabled = true; document.getElementById('i2cScanBox').innerText = 'Keresés folyamatban a buszokon...';
    fetch('/api/i2cscan').then(r=>r.text()).then(txt=>{ document.getElementById('i2cScanBox').innerText = txt; }).catch(e=>{ document.getElementById('i2cScanBox').innerText = 'Hiba: ' + e; }).finally(()=>{ btn.innerText = orig; btn.disabled = false; });
}
setInterval(sensPoll, 3000);
</script>)js";

    html += htmlFoot();
    request->send(200, "text/html", html);
}

void handleSensConfig(AsyncWebServerRequest *request) {
    if(request->hasParam("baud", true)) {
        long b = request->getParam("baud", true)->value().toInt();
        if(b >= 1200 && b <= 921600) {
            gSensRs485Baud = (uint32_t)b;
            if(gRs485Initialized) rs485Init(); 
        }
    }
    if(request->hasParam("addr_windspeed", true)) {
        int v = request->getParam("addr_windspeed", true)->value().toInt();
        if(v >= 1 && v <= 247) gWindSpeed.modbusAddr = (uint8_t)v;
    }
    if(request->hasParam("addr_winddir", true)) {
        int v = request->getParam("addr_winddir", true)->value().toInt();
        if(v >= 1 && v <= 247) gWindDir.modbusAddr = (uint8_t)v;
    }
    if(request->hasParam("addr_sht", true)) {
        int v = request->getParam("addr_sht", true)->value().toInt();
        if(v >= 1 && v <= 247) gSht.modbusAddr = (uint8_t)v;
    }
    if(request->hasParam("addr_rain", true)) {
        int v = request->getParam("addr_rain", true)->value().toInt();
        if(v >= 1 && v <= 247) gRain.modbusAddr = (uint8_t)v;
    }
    gRain.isModbus = request->hasParam("rain_modbus", true);

    saveSensorConfig();
    diagAdd("Szenzor RS485/Modbus beallitasok mentve.");
    request->redirect("/sensors");
}

void handleSensToggle(AsyncWebServerRequest *request) {
    if(!request->hasParam("key", true) || !request->hasParam("on", true)) {
        request->send(400, "text/plain", "hianyzo parameter");
        return;
    }
    String key = request->getParam("key", true)->value();
    bool on = request->getParam("on", true)->value() == "1";

    int bit = -1;
    if(key == "windspeed") bit = SENS_BIT_WINDSPEED;
    else if(key == "winddir") bit = SENS_BIT_WINDDIR;
    else if(key == "sht") bit = SENS_BIT_SHT;
    else if(key == "rain") bit = SENS_BIT_RAIN;
    else if(key == "mpu") bit = SENS_BIT_MPU6050;
    else if(key == "aht20") bit = SENS_BIT_AHT20;
    else if(key == "bmp280") bit = SENS_BIT_BMP280;
    else if(key == "ltr") bit = SENS_BIT_LTR390;

    if(bit < 0) {
        request->send(400, "text/plain", "ismeretlen szenzor");
        return;
    }

    sensSetEnabled((uint8_t)bit, on);
    sensorsApplyEnabled();
    saveSensorConfig();

    String diagMsg = "Szenzor '" + key + "': " + (on ? "bekapcsolva" : "kikapcsolva");
    if(on) {
        sensTestRun(key); 
        if(gLastSensTestOk) diagMsg += " (Komm. OK)";
        else diagMsg += " (HIBA)";
    }
    diagAdd(diagMsg);
    request->send(200, "text/plain", "ok");
}

void handleSensStatus(AsyncWebServerRequest *request) {
    String json = "{";
    json += sensStatusJsonEntry("windspeed", gWindSpeed.enabled, gWindSpeed.lastGoodRead>0, gWindSpeed.lastReadOk, windSpeedValueText()) + ",";
    json += sensStatusJsonEntry("winddir", gWindDir.enabled, gWindDir.lastGoodRead>0, gWindDir.lastReadOk, windDirValueText()) + ",";
    json += sensStatusJsonEntry("sht", gSht.enabled, gSht.lastGoodRead>0, gSht.lastReadOk, shtValueText()) + ",";
    json += sensStatusJsonEntry("rain", gRain.enabled, gRain.lastPoll>0, true, rainValueText()) + ",";
    json += sensStatusJsonEntry("mpu", gMpu.enabled, gMpu.lastGoodRead>0, gMpu.lastReadOk, mpuValueText()) + ",";
    json += sensStatusJsonEntry("aht20", gAht20.enabled, gAht20.lastGoodRead>0, gAht20.lastReadOk, aht20ValueText()) + ",";
    json += sensStatusJsonEntry("bmp280", gBmp280.enabled, gBmp280.lastGoodRead>0, gBmp280.lastReadOk, bmp280ValueText()) + ",";
    json += sensStatusJsonEntry("ltr", gLtr.enabled, gLtr.lastGoodRead>0, gLtr.lastReadOk, ltrValueText());
    json += "}";
    request->send(200, "application/json", json);
}

void handleSensTest(AsyncWebServerRequest *request) {
    if(!request->hasParam("which", true)) {
        request->redirect("/sensors"); return;
    }
    String which = request->getParam("which", true)->value();
    sensTestRun(which);
    diagAdd("Szenzor teszt (" + which + "): " + gLastSensTestResult);
    request->redirect("/sensors");
}

void handleApiI2cScan(AsyncWebServerRequest *request) {
    if (!checkPinGuard(request)) return;
    String res = performI2cScan();
    request->send(200, "text/plain", res);
}