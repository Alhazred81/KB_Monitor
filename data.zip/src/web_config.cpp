#include "web_config.h"
#include "web_common.h"
#include <Arduino.h>
#include <WiFi.h>

extern AsyncWebServer server;

extern String gApSSID;
extern String gApPass;
extern String gStaSSID; 
extern String gStaPass; 
extern int gRadioMode;  // 0: ESP-NOW, 1: LoRa

extern String htmlHead(const String& title, const String& activeTab);
extern String htmlFoot();

void handleConfigPage(AsyncWebServerRequest *request) {
  String html = htmlHead("Kommunikáció", "");
  
  html += "<div class='card wide'>";
  html += "<h2>📡 Kommunikációs Beállítások</h2>";
  html += "<form action='/api/save_config' method='POST'>";
  
  // 1. Rádió protokoll
  html += "<h3>Rádió protokoll (Szerver - Kaptármonitor)</h3>";
  html += "<select name='radio_mode' class='sec' style='width:100%; padding:10px; margin-bottom:20px;'>";
  html += "<option value='0'" + String(gRadioMode == 0 ? " selected" : "") + ">ESP-NOW (2.4 GHz)</option>";
  html += "<option value='1'" + String(gRadioMode == 1 ? " selected" : "") + ">LoRa (SX1262 - 868 MHz)</option>";
  html += "</select>";

  // 2. Wi-Fi Kliens (STA) - Aktuális adatok feltöltésével
  html += "<h3>Helyi Wi-Fi (Szerver internetkapcsolata)</h3>";
  html += "<label>SSID:</label><br>";
  html += "<input type='text' name='sta_ssid' value='" + gStaSSID + "' placeholder='Otthoni Wi-Fi neve' style='width:100%; margin-bottom:10px;'><br>";
  html += "<label>Jelszó:</label><br>";
  html += "<input type='password' name='sta_pass' value='" + gStaPass + "' placeholder='Otthoni Wi-Fi jelszó' style='width:100%; margin-bottom:20px;'><br>";

  // 3. AP Mód
  html += "<h3>Szerver AP (Hotspot) beállítások</h3>";
  html += "<label>AP SSID:</label><br>";
  html += "<input type='text' name='ap_ssid' value='" + gApSSID + "' placeholder='KB-teszt...' style='width:100%; margin-bottom:10px;'><br>";
  html += "<label>AP Jelszó (min 8 kar.):</label><br>";
  html += "<input type='text' name='ap_pass' value='" + gApPass + "' style='width:100%; margin-bottom:20px;'><br>";

  html += "<button type='submit' class='pri' style='width:100%; padding:12px;'>💾 Mentés és Újraindítás</button>";
  html += "</form>";
  html += "</div>";

  // 4. Kényszerített AP gomb
  html += "<div class='card wide' style='margin-top:20px;'>";
  html += "<h3>Kényszerített AP Mód</h3>";
  html += "<p class='hint'>Bontja a kliens Wi-Fi kapcsolatot és azonnal AP módba kapcsol.</p>";
  html += "<button onclick=\"fetch('/api/force_ap').then(()=>alert('AP mód aktiválva. Csatlakozz az eszköz hálózatához.'));\" class='sec' style='width:100%; padding:12px; background:#dc2626; color:white;'>⚠️ Váltás AP módba most</button>";
  html += "</div>";

  html += htmlFoot();
  request->send(200, "text/html", html);
}

void handleSaveConfig(AsyncWebServerRequest *request) {
  if (request->hasParam("radio_mode", true)) {
    gRadioMode = request->getParam("radio_mode", true)->value().toInt();
  }
  if (request->hasParam("sta_ssid", true)) {
    gStaSSID = request->getParam("sta_ssid", true)->value();
  }
  if (request->hasParam("sta_pass", true)) {
    gStaPass = request->getParam("sta_pass", true)->value();
  }
  if (request->hasParam("ap_ssid", true)) {
    gApSSID = request->getParam("ap_ssid", true)->value();
  }
  if (request->hasParam("ap_pass", true)) {
    gApPass = request->getParam("ap_pass", true)->value();
  }

  String response = htmlHead("Mentés...", "");
  response += "<div class='card wide'><h2>✅ Sikeres mentés.</h2><p>A szerver újraindul...</p></div>";
  response += "<script>setTimeout(()=>location.href='/', 5000);</script>";
  response += htmlFoot();
  
  request->send(200, "text/html", response);

  delay(500);
  ESP.restart();
}

void handleForceAp(AsyncWebServerRequest *request) {
  WiFi.disconnect(true, true);
  delay(100);
  WiFi.mode(WIFI_AP);
  WiFi.softAP(gApSSID.c_str(), gApPass.c_str());
  
  request->send(200, "text/plain", "AP mód bekapcsolva.");
}

void initConfigRoutes() {
  server.on("/cfg", HTTP_GET, handleConfigPage);
  server.on("/api/save_config", HTTP_POST, handleSaveConfig);
  server.on("/api/force_ap", HTTP_GET, handleForceAp);
}